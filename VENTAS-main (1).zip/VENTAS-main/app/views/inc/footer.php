<div class="notification is-success is-light pb-6 pt-6" style="font-size: 20px;">
	La versión más actualizada de este sistema está disponible para los <a href="https://www.youtube.com/channel/UCRMJ0vxtnHh_UAq1Yx9BYWQ/join" target="_blank">MIEMBROS del canal de YouTube (Membresía "Programador Semi Senior" o superior)</a>, puede hacerse miembro <a href="https://www.youtube.com/channel/UCRMJ0vxtnHh_UAq1Yx9BYWQ/join" target="_blank">haciendo clic acá</a> o probar la DEMO de la versión actualizada <a href="http://systems.designlopers.com/VENTAS/" target="_blank">haciendo clic aquí</a>.
	<br><br>
	** NOVEDADES **<br>
	- Se agrego reporte general de ventas<br>
	- Se agrego reporte general de inventario<br>
	- Se agrego opción para cambiar logo de la empresa<br> 
	- Se agrego roles de usuario
	<br><br>
	Para eliminar este texto edite el archivo index.php (en la línea 51) y quite el código donde se incluye el archivo footer.php con require_once
</div>